PDCurses Documentation
======================

Some plain text documents to provide a basic overview of PDCurses and
details for specific platforms, along with a program to combine them
with the "man page" sections from the source code files, into
"PDCurses.md".


Building
--------

- Type "make". ("make clean" to remove the built files.) A Unix-like
  environment is required for the Makefile. This is called automatically
  when doing a top-level make of the X11 port.


Distribution Status
-------------------

Public Domain, except for manext.c, which is GPL 2+.
